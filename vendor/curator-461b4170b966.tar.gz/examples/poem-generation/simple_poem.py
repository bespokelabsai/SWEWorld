"""Curator example that uses the base LLM class to generate poems.

Please see the poem.py for more complex use cases.
"""

from bespokelabs import curator

# Use GPT-4o-mini for this example.
llm = curator.LLM(model_name="gpt-4o-mini")
poem = llm(["Write a poem about the importance of data in AI."])
print(poem.dataset.to_pandas().iloc[0]["response"])

# Use Claude Sonnet 4.6 for this example.
llm = curator.LLM(model_name="claude-sonnet-4-6", backend="anthropic")
poem = llm(["Write a poem about the importance of data in AI."])
print(poem.dataset.to_pandas().iloc[0]["response"])

# Note that we can also pass a list of prompts to generate multiple responses.
poems = llm(
    [
        "Write a sonnet about the importance of data in AI.",
        "Write a haiku about the importance of data in AI.",
    ]
)
print(poems.dataset.to_pandas()["response"].tolist())
