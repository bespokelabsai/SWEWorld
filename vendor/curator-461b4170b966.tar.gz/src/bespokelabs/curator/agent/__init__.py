"""Agent module for Curator."""
